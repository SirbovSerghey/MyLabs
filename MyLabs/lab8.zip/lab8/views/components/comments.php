<?php
if (empty($errors)) {
    ?>
    <div id="result" class="comment-result">
        <p>Your name: <b><?php echo $name ?></b></p>
        <p>Your e-mail: <b><?php echo $mail ?></b></p>
        <p>Your comment: <b><?php echo $comment ?></b></p>
    </div>
    <?php
}
?>